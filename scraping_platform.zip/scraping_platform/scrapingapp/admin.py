from django.contrib import admin

# Register your models here.

from .models import ScrapedData

@admin.register(ScrapedData)
class ScrapedDataAdmin(admin.ModelAdmin):
    list_display = ('title', 'url', 'date_scraped')  # Affiche ces champs dans la liste
    search_fields = ('title', 'url')  # Ajoute la fonctionnalité de recherche
