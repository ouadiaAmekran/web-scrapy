# scrapingapp/views.py
from django.shortcuts import render
from django.http import HttpResponse

def home(request):
    if request.method == "GET":
        query = request.GET.get('q', '')  # Récupérer la requête de recherche
        # Vous pouvez ajouter la logique de recherche ici en fonction de la base de données ou d'autres sources.
        results = []  # Remplacez cela par les résultats réels de votre recherche

        return render(request, 'scrapingapp/home.html', {'query': query, 'results': results})
    else:
        return HttpResponse("Méthode non supportée", status=405)

import os
import json
from django.conf import settings
from django.shortcuts import render
from django.http import HttpResponse

def page_tablette_smartphone(request):
    # Chemin complet vers le fichier jumia_data.json dans le dossier price_comparison
    file_path = os.path.join(settings.BASE_DIR, 'price_comparison', 'jumia_data.json')

    if not os.path.exists(file_path):
        return HttpResponse("Le fichier jumia_data.json est introuvable.", status=404)
    
    try:
        # Ouverture et lecture du fichier JSON
        with open(file_path, 'r') as json_file:
            data = json.load(json_file)
    except json.JSONDecodeError:
        return HttpResponse("Erreur lors de la lecture du fichier JSON.", status=500)
    
    # Filtrer les produits pour inclure uniquement ceux de la catégorie "telephone-tablette"
    filtered_data = [product for product in data if product.get('category') == 'telephone-tablette']
    
    # Passez les données filtrées au template
    return render(request, 'scrapingapp/page_tablette_smartphone.html', {'products': filtered_data})



def page_sports_loisirs(request):
    # Chemin complet vers le fichier jumia_data.json dans le dossier price_comparison
    file_path = os.path.join(settings.BASE_DIR, 'price_comparison', 'jumia_data.json')

    if not os.path.exists(file_path):
        return HttpResponse("Le fichier jumia_data.json est introuvable.", status=404)
    
    try:
        # Ouverture et lecture du fichier JSON
        with open(file_path, 'r') as json_file:
            data = json.load(json_file)
    except json.JSONDecodeError:
        return HttpResponse("Erreur lors de la lecture du fichier JSON.", status=500)
    
    # Filtrer les produits pour inclure uniquement ceux de la catégorie "sports-loisirs"
    filtered_data = [product for product in data if product.get('category') == 'fashion-mode']
    
    # Passez les données filtrées au template
    return render(request, 'scrapingapp/page_sports_loisirs.html', {'products': filtered_data})


def page_maison_cuisine_jardin(request):
    # Chemin complet vers le fichier jumia_data.json dans le dossier price_comparison
    file_path = os.path.join(settings.BASE_DIR, 'price_comparison', 'jumia_data.json')

    if not os.path.exists(file_path):
        return HttpResponse("Le fichier jumia_data.json est introuvable.", status=404)
    
    try:
        # Ouverture et lecture du fichier JSON
        with open(file_path, 'r') as json_file:
            data = json.load(json_file)
    except json.JSONDecodeError:
        return HttpResponse("Erreur lors de la lecture du fichier JSON.", status=500)
    
    # Filtrer les produits pour inclure uniquement ceux de la catégorie "maison-cuisine-jardin"
    filtered_data = [product for product in data if product.get('category') == 'maison-cuisine-jardin']
    
    # Passez les données filtrées au template
    return render(request, 'scrapingapp/page_maison_cuisine_jardin.html', {'products': filtered_data})



def page_beaute_hygiene_sante(request):
    # Chemin complet vers le fichier jumia_data.json dans le dossier price_comparison
    file_path = os.path.join(settings.BASE_DIR, 'price_comparison', 'jumia_data.json')

    if not os.path.exists(file_path):
        return HttpResponse("Le fichier jumia_data.json est introuvable.", status=404)
    
    try:
        # Ouverture et lecture du fichier JSON
        with open(file_path, 'r') as json_file:
            data = json.load(json_file)
    except json.JSONDecodeError:
        return HttpResponse("Erreur lors de la lecture du fichier JSON.", status=500)
    
    # Filtrer les produits pour inclure uniquement ceux de la catégorie "beaute-hygiene-sante"
    filtered_data = [product for product in data if product.get('category') == 'beaute-hygiene-sante']
    
    # Passez les données filtrées au template
    return render(request, 'scrapingapp/page_beaute_hygiene_sante.html', {'products': filtered_data})



def page_ordinateurs_accessoires_informatique(request):
    # Chemin complet vers le fichier jumia_data.json dans le dossier price_comparison
    file_path = os.path.join(settings.BASE_DIR, 'price_comparison', 'jumia_data.json')

    if not os.path.exists(file_path):
        return HttpResponse("Le fichier jumia_data.json est introuvable.", status=404)
    
    try:
        # Ouverture et lecture du fichier JSON
        with open(file_path, 'r') as json_file:
            data = json.load(json_file)
    except json.JSONDecodeError:
        return HttpResponse("Erreur lors de la lecture du fichier JSON.", status=500)
    
    # Filtrer les produits pour inclure uniquement ceux de la catégorie "ordinateurs-accessoires-informatique"
    filtered_data = [product for product in data if product.get('category') == 'ordinateurs-accessoires-informatique']
    
    # Passez les données filtrées au template
    return render(request, 'scrapingapp/page_ordinateurs_accessoires_informatique.html', {'products': filtered_data})




# scrapingapp/views.py
import json
import os
from django.conf import settings
from django.shortcuts import render
from django.http import HttpResponse

def categories(request):
    # Chemin complet vers le fichier jumia_data.json dans le dossier price_comparison
    file_path = os.path.join(settings.BASE_DIR, 'price_comparison', 'jumia_data.json')

    if not os.path.exists(file_path):
        return HttpResponse("Le fichier jumia_data.json est introuvable.", status=404)
    
    try:
        # Ouverture et lecture du fichier JSON
        with open(file_path, 'r') as json_file:
            data = json.load(json_file)
    except json.JSONDecodeError:
        return HttpResponse("Erreur lors de la lecture du fichier JSON.", status=500)
    
    # Filtrer les produits pour inclure uniquement ceux de la catégorie souhaitée
    category_filter = 'ordinateurs-accessoires-informatique'  # Remplace par la catégorie souhaitée
    filtered_data = [product for product in data if product.get('category') == category_filter]
    
    # Passez les données filtrées au template
    return render(request, 'scrapingapp/categories.html', {'products': filtered_data})


# scrapingapp/views.py
import json
import os
from django.conf import settings
from django.shortcuts import render
from django.http import HttpResponse

def contact(request):
    # Chemin complet vers le fichier jumia_data.json dans le dossier price_comparison
    file_path = os.path.join(settings.BASE_DIR, 'price_comparison', 'jumia_data.json')

    if not os.path.exists(file_path):
        return HttpResponse("Le fichier jumia_data.json est introuvable.", status=404)
    
    try:
        # Ouverture et lecture du fichier JSON
        with open(file_path, 'r') as json_file:
            data = json.load(json_file)
    except json.JSONDecodeError:
        return HttpResponse("Erreur lors de la lecture du fichier JSON.", status=500)
    
    # Filtrer les produits pour inclure uniquement ceux de la catégorie souhaitée
    category_filter = 'ordinateurs-accessoires-informatique'  # Remplace par la catégorie souhaitée
    filtered_data = [product for product in data if product.get('category') == category_filter]
    
    # Passez les données filtrées au template
    return render(request, 'scrapingapp/contact.html', {'products': filtered_data})




import os
import json
from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import render

def search(request):
    query = request.GET.get('q', '')

    if query:
        jumia_file_path = os.path.join(settings.BASE_DIR, 'price_comparison', 'jumia_data.json')
        amazon_file_path = os.path.join(settings.BASE_DIR, 'price_comparison', 'amazon_data.json')

        # Vérification de l'existence des fichiers
        if not os.path.exists(jumia_file_path) or not os.path.exists(amazon_file_path):
            return HttpResponse("Le fichier JSON est introuvable.", status=404)

        try:
            # Lecture des fichiers JSON
            with open(jumia_file_path, 'r', encoding='utf-8') as jumia_json_file:
                jumia_data = json.load(jumia_json_file)
            
            with open(amazon_file_path, 'r', encoding='utf-8') as amazon_json_file:
                amazon_data = json.load(amazon_json_file)
        except json.JSONDecodeError as e:
            return HttpResponse(f"Erreur JSON: {str(e)}", status=500)
        except Exception as e:
            return HttpResponse(f"Erreur lors de la lecture des fichiers JSON: {str(e)}", status=500)

        # Filtrage des données Jumia
        jumia_products = [product for product in jumia_data if product.get('product_name') and query.lower() in product.get('product_name', '').lower()]
        
        # Filtrage des données Amazon
        amazon_products = [product for product in amazon_data if product.get('name') and query.lower() in product.get('name', '').lower()]

        # Passer les résultats séparément à la vue
        return render(request, 'scrapingapp/search_results.html', {
            'jumia_products': jumia_products,
            'amazon_products': amazon_products,
            'query': query
        })
    else:
        return HttpResponse("Veuillez entrer un terme de recherche.", status=400)
    
    import os
import json
from django.conf import settings
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render

def dashboard(request):
    # Chemins vers les fichiers JSON
    jumia_file_path = os.path.join(settings.BASE_DIR, 'price_comparison', 'jumia_data.json')
    amazon_file_path = os.path.join(settings.BASE_DIR, 'price_comparison', 'amazon_data.json')

    # Vérification de l'existence des fichiers
    if not os.path.exists(jumia_file_path) or not os.path.exists(amazon_file_path):
        return HttpResponse("Le fichier JSON est introuvable.", status=404)

    try:
        # Lecture des fichiers JSON
        with open(jumia_file_path, 'r', encoding='utf-8') as jumia_json_file:
            jumia_data = json.load(jumia_json_file)
        
        with open(amazon_file_path, 'r', encoding='utf-8') as amazon_json_file:
            amazon_data = json.load(amazon_json_file)
    except json.JSONDecodeError as e:
        return HttpResponse(f"Erreur JSON: {str(e)}", status=500)
    except Exception as e:
        return HttpResponse(f"Erreur lors de la lecture des fichiers JSON: {str(e)}", status=500)

    # Filtrage des données si une requête AJAX est envoyée
    query = request.GET.get('q', '')
    if query:
        jumia_products = [product for product in jumia_data if query.lower() in product.get('product_name', '').lower()]
        amazon_products = [product for product in amazon_data if query.lower() in product.get('name', '').lower()]
    else:
        jumia_products = jumia_data
        amazon_products = amazon_data

    # Si la requête est AJAX, renvoyer les données en JSON
    if request.is_ajax():
        return JsonResponse({
            'jumia_products': jumia_products,
            'amazon_products': amazon_products
        })
    
    return render(request, 'scrapingapp/dashboard.html', {
    'jumia_products': jumia_products,
    'amazon_products': amazon_products,
    'query': query
})


 