from django.urls import path
from .views import (
    home, 
    page_tablette_smartphone, 
    page_sports_loisirs, 
    page_maison_cuisine_jardin, 
    page_beaute_hygiene_sante, 
    page_ordinateurs_accessoires_informatique,  # Ensure this view is defined
    categories, 
    contact,
    search

)

urlpatterns = [
    path('', home, name='home'),  # URL for the 'home' view
    path('page_tablette_smartphone/', page_tablette_smartphone, name='page_tablette_smartphone'),  # URL for 'page_tablette_smartphone'
    path('page_sports_loisirs/', page_sports_loisirs, name='page_sports_loisirs'),  # URL for 'page_sports_loisirs'
    path('page_maison_cuisine_jardin/', page_maison_cuisine_jardin, name='page_maison_cuisine_jardin'),  # URL for 'page_maison_cuisine_jardin'
    path('page_beaute_hygiene_sante/', page_beaute_hygiene_sante, name='page_beaute_hygiene_sante'),  # URL for 'page_beaute_hygiene_sante'
    path('page_ordinateurs_accessoires_informatique/', page_ordinateurs_accessoires_informatique, name='page_ordinateurs_accessoires_informatique'),  # Ensure this points to the correct view

    path('categories/', categories, name='categories'),  # URL for 'categories'
    path('categories/page_tablette_smartphone/', page_tablette_smartphone, name='categories_page_tablette_smartphone'),  # Add this line
    path('categories/page_sports_loisirs/', page_sports_loisirs, name='categories_page_sports_loisirs'),
    path('categories/page_maison_cuisine_jardin/', page_sports_loisirs, name='categories_page_maison_cuisine_jardin'),
    path('categories/page_beaute_hygiene_sante/', page_sports_loisirs, name='categories_page_beaute_hygiene_sante'),
    path('categories/page_ordinateurs_accessoires_informatique/', page_sports_loisirs, name='categories_page_ordinateurs_accessoires_informatique'),
    path('contact/', contact, name='contact'),  # URL for 'contact'
     path('search/', search, name='search'),
]
