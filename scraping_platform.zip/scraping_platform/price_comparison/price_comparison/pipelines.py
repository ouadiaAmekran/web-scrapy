import csv
from itemadapter import ItemAdapter

class PriceComparisonPipeline:
    def open_spider(self, spider):
        self.file = open('output.csv', 'w', newline='', encoding='utf-8')
        self.writer = csv.writer(self.file)
        self.writer.writerow(['category', 'product_name', 'product_price', 'product_link', 'product_image'])
    
    def close_spider(self, spider):
        self.file.close()
    
    def process_item(self, item, spider):
        adapter = ItemAdapter(item)
        
        self.writer.writerow([
            adapter.get('category', '').strip(),
            adapter.get('product_name', '').strip(),
            adapter.get('product_price', '').strip(),
            adapter.get('product_link', '').strip(),
            adapter.get('product_image', '').strip(),
        ])
        
        return item
