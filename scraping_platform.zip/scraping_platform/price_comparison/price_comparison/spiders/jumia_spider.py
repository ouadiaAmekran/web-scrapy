import scrapy

class JumiaSpider(scrapy.Spider):
    name = 'jumia_spider'
    start_urls = [
        'https://www.jumia.ma/telephone-tablette/',
        'https://www.jumia.ma/electronique/',
        'https://www.jumia.ma/ordinateurs-accessoires-informatique/',
        'https://www.jumia.ma/maison-cuisine-jardin/',
        'https://www.jumia.ma/mlp-electromenager/',
        'https://www.jumia.ma/fashion-mode/',
        'https://www.jumia.ma/beaute-hygiene-sante/'
    ]

    def parse(self, response):
        # Extraire les cartes de produits dans les balises <a>
        for product in response.xpath('//a[contains(@class, "core")]'):
            # Extraire les informations de chaque produit
            product_info = product.xpath('.//div[contains(@class, "info")]')
            product_name = product_info.xpath('.//h3[contains(@class, "name")]/text()').get()
            product_price = product_info.xpath('.//div[contains(@class, "prc")]/text()').get()
            
            # Extraire l'image du produit
            product_image = product.xpath('.//div[contains(@class, "img-c")]/img/@data-src').get()
            
            # Extraire le lien du produit
            product_link = product.xpath('./@href').get()

            yield {
                'product_name': product_name,
                'product_price': product_price,
                'product_image': product_image,
                'product_link': response.urljoin(product_link),  # URL complète du produit
                'category': response.url.split('/')[-2]  # Ajouter la catégorie à partir de l'URL
            }
        
        # Extraire les liens vers les pages suivantes (si applicable)
        next_page = response.xpath('//a[contains(@class, "pg") and contains(text(),"Suivant")]/@href').get()
        if next_page:
            yield response.follow(next_page, self.parse)

# Paramètres pour enregistrer les données dans des fichiers JSON distincts
from scrapy.utils.project import get_project_settings
settings = get_project_settings()

FEEDS = {
    'output/telephone-tablette.json': {
        'format': 'json',
        'encoding': 'utf8',
        'store_empty': False,
        'fields': None,
        'indent': 4,
    },
    'output/electronique.json': {
        'format': 'json',
        'encoding': 'utf8',
        'store_empty': False,
        'fields': None,
        'indent': 4,
    },
    'output/ordinateurs-accessoires-informatique.json': {
        'format': 'json',
        'encoding': 'utf8',
        'store_empty': False,
        'fields': None,
        'indent': 4,
    },
    'output/maison-cuisine-jardin.json': {
        'format': 'json',
        'encoding': 'utf8',
        'store_empty': False,
        'fields': None,
        'indent': 4,
    },
    'output/mlp-electromenager.json': {
        'format': 'json',
        'encoding': 'utf8',
        'store_empty': False,
        'fields': None,
        'indent': 4,
    },
    'output/fashion-mode.json': {
        'format': 'json',
        'encoding': 'utf8',
        'store_empty': False,
        'fields': None,
        'indent': 4,
    },
    'output/beaute-hygiene-sante.json': {
        'format': 'json',
        'encoding': 'utf8',
        'store_empty': False,
        'fields': None,
        'indent': 4,
    },
}

settings.set('FEEDS', FEEDS)
