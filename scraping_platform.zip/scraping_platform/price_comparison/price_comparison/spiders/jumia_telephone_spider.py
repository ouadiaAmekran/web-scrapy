import scrapy

class JumiaTelephoneSpider(scrapy.Spider):
    name = 'jumia_telephone_spider'
    start_urls = ['https://www.jumia.ma/telephone-tablette/#catalog-listing']

    def parse(self, response):
        # Target 'core' class inside the parent container with class 'aim row -pbm'
        for product in response.xpath('//div[@class="prd _fd col c-prd"]//div[contains(@class, "core")]'):
            product_info = product.xpath('.//div[contains(@class, "info")]')
            product_name = product_info.xpath('.//h3[contains(@class, "name")]/text()').get()
            product_price = product_info.xpath('.//div[contains(@class, "prc")]/text()').get()
            product_image = product.xpath('.//div[contains(@class, "img-c")]/img/@data-src').get()
            product_link = product.xpath('.//a/@href').get()  # Adjusted to get the href from the <a> inside the .core div

            yield {
                'product_name': product_name,
                'product_price': product_price,
                'product_image': response.urljoin(product_image),
                'product_link': response.urljoin(product_link),
                'category': 'telephone-tablette'
            }

        # Adjusted XPath to match pagination link
        next_page = response.xpath('//a[contains(text(),"Suivant")]/@href').get()
        if next_page:
            yield response.follow(next_page, self.parse)
