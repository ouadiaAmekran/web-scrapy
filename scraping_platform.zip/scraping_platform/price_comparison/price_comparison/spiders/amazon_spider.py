import scrapy
from scrapy.utils.project import get_project_settings

class AmazonSpider(scrapy.Spider):
    name = 'amazon_spider'


    custom_settings = {
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36',
        'DOWNLOAD_DELAY': 2  # Avoid hitting Amazon too fast
    }

    # Catégories et sous-catégories avec leurs URLs respectives
    categories = [
        {
            'name': 'Electronics',
            'subcategories': [
                {'name': 'Accessories & Supplies', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'Camera & Photo', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A502394&ref=nav_em__nav_desktop_sa_intl_camera_and_photo_0_2_5_3'},
                {'name': 'Car & Vehicle Electronics', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A3248684011&ref=nav_em__nav_desktop_sa_intl_car_and_vehicle_electronics_0_2_5_4'},
                 {'name': 'Cell Phones & Accessories', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'Computers & Accessories', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'Cell Phones & Accessories', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'GPS & Navigation', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'headphones', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'home_audio', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'Office Electronics', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'Portable Audio & Video', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'Security & Surveillance', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'Televisions & Video Products', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'Video Game Consoles & Accessories', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'Televisions & Video Products', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': 'Video Projectors', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                  {'name': 'Wearable Technology', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
                {'name': ' eBook Readers & Accessories', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225009011&rh=n%3A%2116225009011%2Cn%3A281407&ref=nav_em__nav_desktop_sa_intl_accessories_and_supplies_0_2_5_2'},
        
     
            

            ]
             },


        {
            'name': 'Computer',
            'subcategories': [
                {'name': 'Computer Accessories & Peripherals', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225007011&rh=n%3A16225007011%2Cn%3A172456&ref=nav_em__nav_desktop_sa_intl_computer_accessories_and_peripherals_0_2_6_2'},
                {'name': 'Computer Components', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225007011&rh=n%3A16225007011%2Cn%3A193870011&ref=nav_em__nav_desktop_sa_intl_computer_components_0_2_6_3'},
                {'name': 'Computers & Tablets', 'url': 'https://www.amazon.com/s?i=specialty-aps&bbn=16225007011&rh=n%3A16225007011%2Cn%3A13896617011&ref=nav_em__nav_desktop_sa_intl_computers_tablets_0_2_6_4'},
                # Ajoutez d'autres sous-catégories ici
            ]
        },
        # Ajoutez d'autres catégories principales ici
    ]

    # Démarrer avec toutes les sous-catégories
    start_urls = [subcategory['url'] for category in categories for subcategory in category['subcategories']]

    def parse(self, response):
        # Trouver la catégorie et sous-catégorie associée à l'URL actuelle
        category_name, subcategory_name = self.get_category_and_subcategory(response.url)

        # Extraire les cartes de produits
        for product in response.xpath('//div[contains(@class, "a-section a-spacing-base")]'):
            product_name = product.xpath('.//span[contains(@class, "a-size-base-plus a-color-base a-text-normal")]/text()').get()
            product_price = product.xpath('.//span[contains(@class, "a-offscreen")]/text()').get()
            product_image = product.xpath('.//img[contains(@class, "s-image")]/@src').get()
            product_link = product.xpath('./@href').get()
            product_link = response.urljoin(product_link)

            # Stocker ou traiter les informations extraites avec la catégorie et sous-catégorie
            yield {
                'category': category_name,
                'subcategory': subcategory_name,
                'name': product_name,
                'price': product_price,
                'image': product_image,
                'link': product_link
            }

        # Extraire les liens vers les pages suivantes (si applicable)
        next_page = response.xpath('//a[contains(@class, "s-pagination-next")]/@href').get()
        if next_page:
            yield response.follow(next_page, self.parse)

    def get_category_and_subcategory(self, url):
        # Trouver la catégorie et sous-catégorie correspondant à l'URL
        for category in self.categories:
            for subcategory in category['subcategories']:
                if subcategory['url'] == url:
                    return category['name'], subcategory['name']
        return 'unknown', 'unknown'

# Configuration des fichiers de sortie
settings = get_project_settings()
FEEDS = {
    'output/%(name)s_%(time)s.json': {
        'format': 'json',
        'overwrite': True
    }
}
settings.set('FEEDS', FEEDS)
